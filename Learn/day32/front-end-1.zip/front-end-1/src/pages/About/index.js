import React from 'react';

function About() {
    return <h2>About page</h2>;
}

export default About;
