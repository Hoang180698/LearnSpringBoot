import React from 'react';

function Slides() {
    return <h2>Slides page</h2>;
}

export default Slides;
