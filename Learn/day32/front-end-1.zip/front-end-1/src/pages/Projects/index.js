import React from 'react';

function Projects() {
    return <h2>Projects page</h2>;
}

export default Projects;
