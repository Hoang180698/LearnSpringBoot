/* eslint-disable no-unused-vars */
/* eslint-disable no-undef */
const { override, useBabelRc } = require('customize-cra');

module.exports = override(useBabelRc());
